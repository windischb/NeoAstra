param(
  [Parameter(Mandatory)][string]$Source,
  [Parameter(Mandatory)][string]$Build,
  [string[]]$Targets = @(),
  [string]$Config = 'Release',
  # Full replacement of CMAKE_CXX_FLAGS (the CMake default is "/DWIN32 /D_WINDOWS /GR /EHsc"); empty keeps the default.
  [string]$CxxFlags = ''
)
$ErrorActionPreference = 'Stop'
$Targets = @($Targets | ForEach-Object { $_ -split ',' } | Where-Object { $_ })
$tc = "$env:USERPROFILE\neoastra-toolchain"
& 'C:\Program Files\Microsoft Visual Studio\18\Enterprise\Common7\Tools\Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation | Out-Null
$env:PATH = "$tc\llvm\bin;$tc\cmake\bin;$tc\ninja;$tc\python-3.15.2\tools;$env:PATH"
$env:DOTNET_ROOT = "$env:USERPROFILE\.dotnet\neoastra-sdk-10.0.114"
$sdk = "$tc\webview2-sdk-1.0.4078.44"   # same pinned package as CMake's FetchContent; avoids a download
$configure = @('-S', $Source, '-B', $Build, '-G', 'Ninja', "-DCMAKE_BUILD_TYPE=$Config", '-DCMAKE_C_COMPILER=clang-cl', '-DCMAKE_CXX_COMPILER=clang-cl',
  '-DNEOASTRA_BUILD_TESTS=ON', '-DNEOASTRA_ENABLE_LTO=OFF', "-DFETCHCONTENT_SOURCE_DIR_WEBVIEW2_SDK=$sdk", '-DFETCHCONTENT_FULLY_DISCONNECTED=ON')
if ($CxxFlags) { $configure += "-DCMAKE_CXX_FLAGS=$CxxFlags" }
cmake @configure
if ($LASTEXITCODE) { exit $LASTEXITCODE }
if ($Targets.Count) { cmake --build $Build --target @Targets } else { cmake --build $Build }
if ($LASTEXITCODE) { exit $LASTEXITCODE }
Write-Output "BUILD OK $Build"
