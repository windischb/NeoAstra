param([string]$Phase = 'after')
# Clean configure and build of the work tree WITHOUT any external NOMINMAX flag (the parent's common fix is in the tree), then
# the three Windows integration executables and the non-activating native suite.
$ErrorActionPreference = 'Continue'
$src = 'C:\Users\bwi\neoastra-src'
$res = "$src\results\$Phase"
New-Item -ItemType Directory -Force $res | Out-Null
Remove-Item "$src\build-work" -Recurse -Force -ErrorAction SilentlyContinue
& pwsh -NoProfile -File "$src\build-native.ps1" -Source "$src\work" -Build "$src\build-work" *> "$res\build.log"
"full build exit $LASTEXITCODE (no external CXX flags)" | Tee-Object "$res\summary.log"
if ($LASTEXITCODE) { Get-Content "$res\build.log" -Tail 30; exit 1 }
Select-String -Path "$src\build-work\CMakeCache.txt" -Pattern '^CMAKE_CXX_FLAGS:' | ForEach-Object { "cache: $($_.Line)" } | Tee-Object -Append "$res\summary.log"
Push-Location "$src\build-work"
foreach ($name in 'failure', 'main', 'absent') {
  $exe = switch ($name) { 'failure' { 'neoastra_windows_request_filter_failure_tests.exe' } 'main' { 'neoastra_windows_request_filter_tests.exe' } 'absent' { 'neoastra_windows_request_filter_absent_tests.exe' } }
  & ".\$exe" *> "$res\$name.log"
  "$name exit $LASTEXITCODE" | Tee-Object -Append "$res\summary.log"
}
$env:PATH = "$env:USERPROFILE\neoastra-toolchain\cmake\bin;$env:PATH"
ctest -R "neoastra_(abi_tests|abi_1_7|common_tests|request_filter_tests|completion_tests|script_world|request_filter_operation|stress)" --output-on-failure --timeout 300 *> "$res\ctest.log"
"ctest (non-GUI) exit $LASTEXITCODE" | Tee-Object -Append "$res\summary.log"
Pop-Location
Get-Content "$res\summary.log"
foreach ($name in 'failure', 'main', 'absent') { "--- $name (tail)"; Get-Content "$res\$name.log" | Select-Object -Last 14 }
