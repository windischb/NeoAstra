p = r'C:\Users\bwi\neoastra-src\work\native\src\windows\windows_backend.cpp'
s = open(p, encoding='utf-8', newline='').read()
assert '\r' not in s

def once(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:100])
    s = s.replace(old, new)

# diagnostic injection point: hold the request but withhold the disposal of the view
once('''    if (state && !state->quarantined) {
        state->quarantined = true;
        if (!view->retain()) return;''', '''    if (state && !state->quarantined) {
        state->quarantined = true;
        if (test_inject_failure("no_dispose")) return; // Test builds: observe the hold on its own, before any disposal.
        if (!view->retain()) return;''')

# a held deferral is never released: releasing it after Close() lets the runtime send the request
once('''if(state->controller)state->controller->Close();delete state;''',
     '''if(state->controller)state->controller->Close();for(auto& held:state->held_requests)(void)held.Detach();delete state;''')
open(p, 'w', encoding='utf-8', newline='').write(s)

p = r'C:\Users\bwi\neoastra-src\work\native\tests\windows_request_filter_tests.cpp'
s = open(p, encoding='utf-8', newline='').read()
assert '\r' not in s
once('''    run_failure_case(w, "construction and prepared answer fail every time (request held, view quarantined)", "create=all,prepared=all", true, true);''',
     '''    run_failure_case(w, "construction and prepared answer fail every time, disposal withheld (the hold on its own)", "create=all,prepared=all,no_dispose=all", false, true);
    run_failure_case(w, "construction and prepared answer fail every time (request held, view quarantined)", "create=all,prepared=all", true, true);''')
open(p, 'w', encoding='utf-8', newline='').write(s)
print('step 3 ok')
