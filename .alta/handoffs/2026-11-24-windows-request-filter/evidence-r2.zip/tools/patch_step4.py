p = r'C:\Users\bwi\neoastra-src\work\native\src\windows\windows_backend.cpp'
s = open(p, encoding='utf-8', newline='').read()
assert '\r' not in s

def once(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:100])
    s = s.replace(old, new)

# timeline trace (test builds only), on the QueryPerformanceCounter clock the host fixture uses too
once('''#else
constexpr bool test_inject_failure(const char*) noexcept { return false; }
#endif
''', '''
long long trace_microseconds() noexcept {
    LARGE_INTEGER counter{}, frequency{};
    QueryPerformanceCounter(&counter);
    QueryPerformanceFrequency(&frequency);
    return counter.QuadPart * 1000000LL / frequency.QuadPart;
}
void rf_trace(const char* what) noexcept { std::fprintf(stderr, "[rf-trace %lld us] %s\\n", trace_microseconds(), what); std::fflush(stderr); }
#else
constexpr bool test_inject_failure(const char*) noexcept { return false; }
inline void rf_trace(const char*) noexcept {}
#endif
''')

once('''    const bool held = SUCCEEDED(result) && deferral;
    if (held) {''', '''    const bool held = SUCCEEDED(result) && deferral;
#ifdef NEOASTRA_WINDOWS_TEST_HOOKS
    if (held) {
        ComPtr<ICoreWebView2WebResourceRequest> traced;
        LPWSTR traced_uri{};
        if (SUCCEEDED(args->get_Request(&traced)) && SUCCEEDED(traced->get_Uri(&traced_uri))) {
            std::string text = "deferral held for " + narrow(traced_uri);
            CoTaskMemFree(traced_uri);
            rf_trace(text.c_str());
        }
    }
#endif
    if (held) {''')
once('''        if (neoastra_app_dispatch(view->environment->app, dispose_quarantined_view, view) != NEOASTRA_OK) {''',
     '''        rf_trace("dispose scheduled");
        if (neoastra_app_dispatch(view->environment->app, dispose_quarantined_view, view) != NEOASTRA_OK) {''')
once('''    auto* view = static_cast<neoastra_view_t*>(pointer);
    try {
        const std::string description = "The request filter could not refuse a request; the view was disposed";''', '''    auto* view = static_cast<neoastra_view_t*>(pointer);
    rf_trace("dispose begins");
    try {
        const std::string description = "The request filter could not refuse a request; the view was disposed";''')
once('''    view->destroy_ui_once();
    view->release();
}

// The refusal of a request, in this order''', '''    view->destroy_ui_once();
    rf_trace("dispose ends");
    view->release();
}

// The refusal of a request, in this order''')
once('''    state->core->remove_WebResourceRequested(state->web_resource_requested);''', '''    rf_trace("removing the WebResourceRequested handler");
    if (!test_inject_failure("skip_handler_removal")) state->core->remove_WebResourceRequested(state->web_resource_requested);
    rf_trace("WebResourceRequested handler removal done");''')
once('''end_page_drag(state);remove_view_events(state);''', '''end_page_drag(state);rf_trace("teardown: removing events");remove_view_events(state);rf_trace("teardown: events removed");''')
once('''if(state->controller)state->controller->Close();for(auto& held:state->held_requests)(void)held.Detach();delete state;''',
     '''if(state->controller){rf_trace("teardown: closing the controller");if(!test_inject_failure("skip_close"))state->controller->Close();rf_trace("teardown: controller closed");}for(auto& held:state->held_requests)(void)held.Detach();rf_trace("teardown: deleting the view state");delete state;''')
open(p, 'w', encoding='utf-8', newline='').write(s)

p = r'C:\Users\bwi\neoastra-src\work\native\tests\windows_request_filter_tests.cpp'
s = open(p, encoding='utf-8', newline='').read()
assert '\r' not in s
once('''            {
                std::lock_guard lock(mutex_);
                const auto path = target.substr(0, target.find('?'));''', '''            if (std::getenv("NEOASTRA_RF_HOST_TRACE")) {
                LARGE_INTEGER counter{}, frequency{};
                QueryPerformanceCounter(&counter);
                QueryPerformanceFrequency(&frequency);
                std::fprintf(stderr, "[host  %lld us] request %s %s on port %d (%zu bytes)\\n", counter.QuadPart * 1000000LL / frequency.QuadPart, method.c_str(), target.c_str(), c.port, total);
                std::fflush(stderr);
            }
            {
                std::lock_guard lock(mutex_);
                const auto path = target.substr(0, target.find('?'));''')
once('''    run_failure_case(w, "construction and prepared answer fail every time (request held, view quarantined)", "create=all,prepared=all", true, true);''',
     '''    run_failure_case(w, "construction and prepared answer fail every time (request held, view quarantined)", "create=all,prepared=all", true, false);
    run_failure_case(w, "DIAGNOSTIC quarantine with the handler removal skipped", "create=all,prepared=all,skip_handler_removal=all", true, false);
    run_failure_case(w, "DIAGNOSTIC quarantine with the controller Close skipped", "create=all,prepared=all,skip_close=all", true, false);''')
once('''    fixture host;
    g_host = &host;''', '''    fixture host;
    g_host = &host;
#ifdef NEOASTRA_FAILURE_ONLY
    SetEnvironmentVariableA("NEOASTRA_RF_HOST_TRACE", "1");
#endif''')
open(p, 'w', encoding='utf-8', newline='').write(s)
print('step 4 ok')
