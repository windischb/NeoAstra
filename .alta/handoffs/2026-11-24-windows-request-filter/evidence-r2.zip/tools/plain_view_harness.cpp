// Minimal plain-view C-ABI harness (no filter, no test hooks, no NeoAstra internals). The same executable runs against the
// pristine-overlaid library and the modified library, to separate harness/baseline behavior from a backend regression.
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#define FD_SETSIZE 1024
#include <winsock2.h>
#include <windows.h>
#include "neoastra.h"
#include <atomic>
#include <chrono>
#include <cstdio>
#include <string>
#include <thread>
#include <filesystem>

static std::atomic<unsigned long long> g_accepts{}, g_raw{}, g_requests{};
static std::atomic<bool> g_stop{false};
static SOCKET g_listener = INVALID_SOCKET;
static int g_port{};

static void server() {
    std::vector<SOCKET> connections;
    while (!g_stop) {
        fd_set set; FD_ZERO(&set); FD_SET(g_listener, &set);
        for (auto s : connections) FD_SET(s, &set);
        timeval timeout{0, 20000};
        if (select(0, &set, nullptr, nullptr, &timeout) <= 0) continue;
        if (FD_ISSET(g_listener, &set)) { SOCKET a = accept(g_listener, nullptr, nullptr); if (a != INVALID_SOCKET) { connections.push_back(a); ++g_accepts; } }
        for (size_t i = 0; i < connections.size();) {
            bool keep = true;
            if (FD_ISSET(connections[i], &set)) {
                char buffer[65536];
                const int n = recv(connections[i], buffer, sizeof(buffer), 0);
                if (n <= 0) keep = false;
                else {
                    g_raw += static_cast<unsigned>(n);
                    if (std::string(buffer, n).find("\r\n\r\n") != std::string::npos) {
                        ++g_requests;
                        const std::string body = "<!doctype html><title>harness</title>ok";
                        const auto reply = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: " + std::to_string(body.size()) + "\r\nConnection: keep-alive\r\n\r\n" + body;
                        send(connections[i], reply.data(), static_cast<int>(reply.size()), 0);
                    }
                }
            }
            if (!keep) { closesocket(connections[i]); connections.erase(connections.begin() + static_cast<std::ptrdiff_t>(i)); } else ++i;
        }
    }
    for (auto s : connections) closesocket(s);
}

template <class F> static bool pump_until(F&& f, int ms) {
    const auto end = std::chrono::steady_clock::now() + std::chrono::milliseconds(ms);
    while (!f()) {
        if (std::chrono::steady_clock::now() >= end) return false;
        MSG m{};
        while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&m); DispatchMessageW(&m); }
        std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }
    return true;
}
struct created { bool done{}; neoastra_result_t result{NEOASTRA_ERROR_UNKNOWN}; void* value{}; DWORD thread{}; };
static void NEOASTRA_CALL on_env(void* p, neoastra_result_t r, neoastra_environment_t* v, const neoastra_error_t*) { *static_cast<created*>(p) = {true, r, v, GetCurrentThreadId()}; }
static void NEOASTRA_CALL on_view(void* p, neoastra_result_t r, neoastra_view_t* v, const neoastra_error_t*) { *static_cast<created*>(p) = {true, r, v, GetCurrentThreadId()}; }
static std::atomic<int> g_started{}, g_finished{}, g_events{};
static void NEOASTRA_CALL on_event(void*, const neoastra_event_t* e) {
    ++g_events;
    if (e->header.type == NEOASTRA_EVENT_NAVIGATION_STARTED) ++g_started;
    if (e->header.type == NEOASTRA_EVENT_NAVIGATION_COMPLETED || e->header.type == NEOASTRA_EVENT_NAVIGATION_FAILED) ++g_finished;
}
struct sres { bool done{}; neoastra_result_t result{NEOASTRA_ERROR_UNKNOWN}; std::string value; };
static void NEOASTRA_CALL on_string(void* p, neoastra_result_t r, neoastra_string_view_t v, const neoastra_error_t*) {
    auto* s = static_cast<sres*>(p); s->result = r; s->value.assign(reinterpret_cast<const char*>(v.data), v.data ? v.length : 0); s->done = true;
}

int wmain(int argc, wchar_t** argv) {
    const bool show = argc > 1 && std::wstring(argv[1]) == L"show";
    WSADATA wsa; WSAStartup(MAKEWORD(2, 2), &wsa);
    g_listener = socket(AF_INET, SOCK_STREAM, 0);
    sockaddr_in a{}; a.sin_family = AF_INET; a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    bind(g_listener, reinterpret_cast<sockaddr*>(&a), sizeof(a)); listen(g_listener, 8);
    int len = sizeof(a); getsockname(g_listener, reinterpret_cast<sockaddr*>(&a), &len); g_port = ntohs(a.sin_port);
    std::thread srv(server);
    const DWORD ui_thread = GetCurrentThreadId();
    std::printf("mode=%s ui_thread=%lu port=%d\n", show ? "shown-offscreen-noactivate" : "hidden-window", ui_thread, g_port);

    neoastra_app_options_t app_options{}; app_options.size = sizeof(app_options); app_options.version = 1; app_options.shutdown_mode = NEOASTRA_APP_SHUTDOWN_EXPLICIT;
    neoastra_app_t* app{};
    std::printf("app_attach=%d\n", static_cast<int>(neoastra_app_attach(&app_options, &app, nullptr)));
    neoastra_window_options_t wo{}; wo.size = sizeof(wo); wo.version = 1; wo.bounds = {-30000, -30000, 640, 480}; wo.flags = 3;
    neoastra_window_t* window{};
    std::printf("create_window=%d\n", static_cast<int>(neoastra_app_create_window(app, &wo, &window, nullptr)));
    if (show) {
        neoastra_native_handle_t handle{}; handle.size = sizeof(handle); handle.version = 1;
        neoastra_window_get_native_handle(window, NEOASTRA_NATIVE_HANDLE_WIN32_HWND, &handle);
        ShowWindow(static_cast<HWND>(handle.value), SW_SHOWNOACTIVATE); // no activation, no input capture
    }
    wchar_t temp[MAX_PATH]{}; GetTempPathW(MAX_PATH, temp);
    const auto root = std::filesystem::path(temp) / ("neoastra-harness-" + std::to_string(GetCurrentProcessId()) + "-" + std::to_string(GetTickCount64()));
    const auto root_text = root.u8string();
    neoastra_environment_options_t eo{}; eo.size = sizeof(eo); eo.version = 1; eo.user_data_root = {reinterpret_cast<const uint8_t*>(root_text.data()), root_text.size()};
    created env;
    std::printf("environment_create_async=%d\n", static_cast<int>(neoastra_environment_create_async(app, &eo, on_env, &env, nullptr, nullptr)));
    std::printf("environment completion within 30s: %d result=%d thread_is_ui=%d\n", pump_until([&] { return env.done; }, 30000), static_cast<int>(env.result), env.thread == ui_thread);
    neoastra_view_options_t vo{}; vo.size = sizeof(vo); vo.version = 1; vo.window = window; vo.fill_parent = 1;
    created view;
    std::printf("view_create_async=%d\n", static_cast<int>(neoastra_environment_create_view_async(static_cast<neoastra_environment_t*>(env.value), &vo, on_view, &view, nullptr, nullptr)));
    std::printf("view completion within 30s: %d result=%d thread_is_ui=%d\n", pump_until([&] { return view.done; }, 30000), static_cast<int>(view.result), view.thread == ui_thread);
    auto* v = static_cast<neoastra_view_t*>(view.value);
    neoastra_view_set_event_callback(v, on_event, nullptr);
    const std::string address = "http://127.0.0.1:" + std::to_string(g_port) + "/plain";
    neoastra_error_t* error{};
    std::printf("view_navigate=%d\n", static_cast<int>(neoastra_view_navigate(v, {reinterpret_cast<const uint8_t*>(address.data()), address.size()}, &error)));
    const bool finished = pump_until([&] { return g_finished.load() > 0; }, 20000);
    std::printf("navigation finished within 20s: %d (started=%d finished=%d events=%d)\n", finished, g_started.load(), g_finished.load(), g_events.load());
    std::printf("host: tcp_accepts=%llu raw_bytes=%llu http_requests=%llu\n", g_accepts.load(), g_raw.load(), g_requests.load());
    for (const char* script : {"location.href", "document.title"}) {
        sres r;
        const std::string js = script;
        const auto rc = neoastra_view_evaluate_script_async(v, {reinterpret_cast<const uint8_t*>(js.data()), js.size()}, on_string, &r, nullptr, nullptr);
        const bool done = pump_until([&] { return r.done; }, 10000);
        std::printf("evaluate(%s): call=%d completed=%d result=%d value=%s\n", script, static_cast<int>(rc), done, static_cast<int>(r.result), r.value.c_str());
    }
    neoastra_view_release(v);
    neoastra_window_release(window);
    neoastra_environment_release(static_cast<neoastra_environment_t*>(env.value));
    neoastra_app_detach(app, nullptr);
    neoastra_app_release(app);
    g_stop = true; srv.join(); closesocket(g_listener); WSACleanup();
    std::error_code ignored; std::filesystem::remove_all(root, ignored);
    return finished ? 0 : 2;
}
