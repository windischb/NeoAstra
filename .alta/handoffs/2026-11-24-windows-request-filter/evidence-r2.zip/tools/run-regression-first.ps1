param([string]$Phase = 'before')
# Builds the work tree and runs the regression tests. TEMPORARY LOCAL FLAG: /DNOMINMAX only works around the unfixed common include
# (request_filter.cpp pulls in winsock2.h); it goes away with the parent's common source. It is NOT part of the delivered patch.
$ErrorActionPreference = 'Continue'
$src = 'C:\Users\bwi\neoastra-src'
$res = "$src\results\$Phase"
New-Item -ItemType Directory -Force $res | Out-Null
$flags = '/DNOMINMAX /DWIN32 /D_WINDOWS /GR /EHsc'
& pwsh -NoProfile -File "$src\build-native.ps1" -Source "$src\work" -Build "$src\build-work" -CxxFlags $flags `
  -Targets 'neoastra_native,neoastra_native_test_hooks,neoastra_windows_request_filter_tests,neoastra_windows_request_filter_absent_tests,neoastra_windows_request_filter_failure_tests' *> "$res\build.log"
"build exit $LASTEXITCODE" | Tee-Object "$res\summary.log"
if ($LASTEXITCODE) { Get-Content "$res\build.log" -Tail 25; exit 1 }
Push-Location "$src\build-work"
foreach ($name in 'failure', 'main', 'absent') {
  $exe = switch ($name) { 'failure' { 'neoastra_windows_request_filter_failure_tests.exe' } 'main' { 'neoastra_windows_request_filter_tests.exe' } 'absent' { 'neoastra_windows_request_filter_absent_tests.exe' } }
  & ".\$exe" *> "$res\$name.log"
  "$name exit $LASTEXITCODE" | Tee-Object -Append "$res\summary.log"
}
Pop-Location
Get-Content "$res\summary.log"
foreach ($name in 'failure', 'main', 'absent') { "--- $name (tail)"; Get-Content "$res\$name.log" | Select-Object -Last 12 }
