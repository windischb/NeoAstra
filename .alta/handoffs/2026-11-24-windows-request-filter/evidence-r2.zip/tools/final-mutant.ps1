$ErrorActionPreference = 'Continue'
$src = 'C:\Users\bwi\neoastra-src'
$res = "$src\results\final"
Remove-Item "$src\mutant" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "$src\build-mutant" -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item "$src\work" "$src\mutant" -Recurse
$file = "$src\mutant\native\src\windows\windows_backend.cpp"
$text = [IO.File]::ReadAllText($file)
$needle = 'return snapshot && !snapshot->empty() && snapshot->refuses(uri, kind);'
if (-not $text.Contains($needle)) { "MUTANT: needle missing" | Tee-Object "$res\mutant-summary.log"; exit 3 }
[IO.File]::WriteAllText($file, $text.Replace($needle, 'return false; /* MUTANT: never refuse */ (void)snapshot; (void)uri; (void)kind;'))
& pwsh -NoProfile -File "$src\build-native.ps1" -Source "$src\mutant" -Build "$src\build-mutant" -Targets 'neoastra_native,neoastra_windows_request_filter_tests' *> "$res\mutant-build.log"
"mutant build exit $LASTEXITCODE (refusal decision replaced by 'never refuse')" | Tee-Object "$res\mutant-summary.log"
if ($LASTEXITCODE) { exit 1 }
Push-Location "$src\build-mutant"
& .\neoastra_windows_request_filter_tests.exe *> "$res\mutant-main.log"
"mutant main-test exit $LASTEXITCODE (nonzero expected: the tests must detect the missing refusal)" | Tee-Object -Append "$res\mutant-summary.log"
Pop-Location
Get-Content "$res\mutant-summary.log"
Get-Content "$res\mutant-main.log" | Select-Object -Last 6
Remove-Item "$src\mutant" -Recurse -Force -ErrorAction SilentlyContinue
