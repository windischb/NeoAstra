$ErrorActionPreference = 'Stop'
$tc = "$env:USERPROFILE\neoastra-toolchain"
& 'C:\Program Files\Microsoft Visual Studio\18\Enterprise\Common7\Tools\Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation | Out-Null
$env:PATH = "$tc\llvm\bin;$env:PATH"
$src = 'C:\Users\bwi\neoastra-src'
$out = "$src\results\harness"
New-Item -ItemType Directory -Force $out | Out-Null
$inc = "$src\work\native\include"   # public header, identical in both trees
$sets = @{ baseline = "$src\build-baseline"; modified = "$src\build-work" }
foreach ($name in $sets.Keys) {
  $dir = "$out\$name"
  New-Item -ItemType Directory -Force $dir | Out-Null
  Copy-Item "$($sets[$name])\neoastra_native.dll" $dir
  clang-cl /nologo /EHsc /std:c++20 /MT "/I$inc" "$src\tools\plain_view_harness.cpp" "/Fe$dir\harness.exe" "/Fo$dir\harness.obj" /link /nologo "$($sets[$name])\neoastra_native.lib" ws2_32.lib user32.lib
  if ($LASTEXITCODE) { throw "harness build failed ($name)" }
}
foreach ($name in 'baseline', 'modified') {
  foreach ($mode in 'hidden', 'show') {
    $log = "$out\$name-$mode.log"
    Push-Location "$out\$name"
    & .\harness.exe $mode *> $log
    "exit $LASTEXITCODE" | Add-Content $log
    Pop-Location
    "== $name / $mode"; Get-Content $log
  }
}
