p = r'C:\Users\bwi\neoastra-src\work\native\src\windows\windows_backend.cpp'
s = open(p, encoding='utf-8', newline='').read()
assert '\r' not in s

def once(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:100])
    s = s.replace(old, new)

# DIAGNOSTIC ONLY (test builds): cancellation primitives tried before the teardown of a view that holds a request
once('''    view->destroy_ui_once();
    rf_trace("dispose ends");''', '''#ifdef NEOASTRA_WINDOWS_TEST_HOOKS
    if (auto* held_state = static_cast<windows_view*>(view->platform); held_state && held_state->core) {
        if (test_inject_failure("pre_stop")) { rf_trace("diagnostic: Stop()"); (void)held_state->core->Stop(); }
        if (test_inject_failure("pre_blank")) { rf_trace("diagnostic: Navigate(about:blank)"); (void)held_state->core->Navigate(L"about:blank"); }
        if (test_inject_failure("pre_wait")) {
            rf_trace("diagnostic: pumping 600 ms before the teardown");
            const auto until = GetTickCount64() + 600;
            while (GetTickCount64() < until) {
                MSG message{};
                while (PeekMessageW(&message, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&message); DispatchMessageW(&message); }
                Sleep(5);
            }
            rf_trace("diagnostic: pump finished");
        }
    }
#endif
    view->destroy_ui_once();
    rf_trace("dispose ends");''')
open(p, 'w', encoding='utf-8', newline='').write(s)

p = r'C:\Users\bwi\neoastra-src\work\native\tests\windows_request_filter_tests.cpp'
s = open(p, encoding='utf-8', newline='').read()
once('''    run_failure_case(w, "DIAGNOSTIC quarantine with the handler removal skipped", "create=all,prepared=all,skip_handler_removal=all", true, false);
    run_failure_case(w, "DIAGNOSTIC quarantine with the controller Close skipped", "create=all,prepared=all,skip_close=all", true, false);''',
     '''    run_failure_case(w, "DIAGNOSTIC Stop() before the teardown", "create=all,prepared=all,pre_stop=all", true, false);
    run_failure_case(w, "DIAGNOSTIC Stop() and a 600 ms pump before the teardown", "create=all,prepared=all,pre_stop=all,pre_wait=all", true, false);
    run_failure_case(w, "DIAGNOSTIC Navigate(about:blank) and a 600 ms pump before the teardown", "create=all,prepared=all,pre_blank=all,pre_wait=all", true, false);
    run_failure_case(w, "DIAGNOSTIC Stop(), Navigate(about:blank) and a 600 ms pump before the teardown", "create=all,prepared=all,pre_stop=all,pre_blank=all,pre_wait=all", true, false);''')
open(p, 'w', encoding='utf-8', newline='').write(s)
print('step 5 ok')
