p = r'C:\Users\bwi\neoastra-src\work\native\src\windows\windows_backend.cpp'
s = open(p, encoding='utf-8', newline='').read()
assert '\r' not in s

def once(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:100])
    s = s.replace(old, new)

# ---- remove the diagnostic timeline and teardown switches (their evidence lives in the logs, not in the product code)
once('''
long long trace_microseconds() noexcept {
    LARGE_INTEGER counter{}, frequency{};
    QueryPerformanceCounter(&counter);
    QueryPerformanceFrequency(&frequency);
    return counter.QuadPart * 1000000LL / frequency.QuadPart;
}
void rf_trace(const char* what) noexcept { std::fprintf(stderr, "[rf-trace %lld us] %s\\n", trace_microseconds(), what); std::fflush(stderr); }
#else
constexpr bool test_inject_failure(const char*) noexcept { return false; }
inline void rf_trace(const char*) noexcept {}
#endif
''', '''#else
constexpr bool test_inject_failure(const char*) noexcept { return false; }
#endif
''')
once('''    state->core->remove_WebResourceRequested(state->web_resource_requested);''' if False else '''    rf_trace("removing the WebResourceRequested handler");
    if (!test_inject_failure("skip_handler_removal")) state->core->remove_WebResourceRequested(state->web_resource_requested);
    rf_trace("WebResourceRequested handler removal done");''', '''    state->core->remove_WebResourceRequested(state->web_resource_requested);''')
once('''end_page_drag(state);rf_trace("teardown: removing events");remove_view_events(state);rf_trace("teardown: events removed");''', '''end_page_drag(state);remove_view_events(state);''')
once('''if(state->controller){rf_trace("teardown: closing the controller");if(!test_inject_failure("skip_close"))state->controller->Close();rf_trace("teardown: controller closed");}for(auto& held:state->held_requests)(void)held.Detach();rf_trace("teardown: deleting the view state");delete state;''',
     '''if(state->controller)state->controller->Close();delete state;''')

# ---- the refusal path: fresh 403, prepared 403, then freeze the view with the request held
start = s.index('// Disposes ONLY the affected view, from the dispatcher')
end = s.index('neoastra_result_t ensure_request_filter_hook(')
refuse = r'''// The refusal of a request, in this order: a fresh empty 403, the prepared 403, and when neither can be assigned the request is
// HELD in a deferral that is never completed, and the host is told once that the view cannot be trusted any more.
//
// KNOWN BLOCKER (measured, not fail-closed): a held request stays unsent for as long as the view lives, but EVERY teardown of the
// view (removing the handler, closing the controller, deleting the state) lets the engine send it a few milliseconds later, and
// neither Stop() nor Close() discards it on their own. This path is reached only when WebView2 refuses BOTH response
// assignments, so the backend does not dispose the view itself (that would release the request); it freezes it.
// A failed HRESULT does not stop a subresource either: the engine sends the request unless it got a response or is held.
void refuse_request(neoastra_view_t* view, ICoreWebView2WebResourceRequestedEventArgs* args, bool document) noexcept {
    auto* state = static_cast<windows_view*>(view->platform);
    neoastra_resource_response_t refused{};
    refused.size = sizeof(refused);
    refused.version = 1;
    refused.status_code = 403;
    ComPtr<ICoreWebView2WebResourceResponse> fresh;
    auto result = test_inject_failure("create") ? E_FAIL : create_resource_response(view, refused, &fresh);
    if (SUCCEEDED(result) && fresh) {
        result = test_inject_failure("assign") ? E_FAIL : args->put_Response(fresh.Get());
        if (SUCCEEDED(result)) return;
    } else if (SUCCEEDED(result)) result = E_FAIL;
    neo_log(view->environment->app, NEOASTRA_LOG_ERROR, "request_filter", "Could not refuse a request with a fresh response", result);
    if (state && state->denial_response && !test_inject_failure("prepared")) {
        result = test_inject_failure("assign_prepared") ? E_FAIL : args->put_Response(state->denial_response.Get());
        if (SUCCEEDED(result)) return;
        neo_log(view->environment->app, NEOASTRA_LOG_ERROR, "request_filter", "Could not refuse a request with the prepared response", result);
    }
    ComPtr<ICoreWebView2Deferral> deferral;
    result = test_inject_failure("defer") ? E_FAIL : args->GetDeferral(&deferral);
    const bool held = SUCCEEDED(result) && deferral;
    if (held) {
        bool stored = false;
        try { if (state) { state->held_requests.push_back(deferral); stored = true; } }
        catch (...) { }
        if (!stored) (void)deferral.Detach(); // Never release an uncompleted deferral that is not stored.
    } else {
        neo_log(view->environment->app, NEOASTRA_LOG_ERROR, "request_filter", "UNSAFE: a request could be neither refused nor held", result);
        // Last resort, no safe path is claimed: Stop() only reaches what the engine is already fetching.
        if (document && state && state->core) (void)state->core->Stop();
    }
    if (state && !state->quarantined) {
        state->quarantined = true;
        try {
            const std::string description = "The request filter could not refuse a request; the view is frozen and must be recreated";
            neo_emit_view(view, NEOASTRA_EVENT_WEB_PROCESS_TERMINATED, 0, &description, nullptr,
                          NEOASTRA_PROCESS_FAILURE_UNKNOWN | NEOASTRA_PROCESS_FAILURE_RECREATE_VIEW, 0);
        } catch (...) { }
    }
}

'''
s = s[:start] + refuse + s[end:]
open(p, 'w', encoding='utf-8', newline='').write(s)

p = r'C:\Users\bwi\neoastra-src\work\native\tests\windows_request_filter_tests.cpp'
s = open(p, encoding='utf-8', newline='').read()
assert '\r' not in s
# the failure tests: protection cases assert silence; the sustained-failure cases assert the HOLD while the view lives and observe, without asserting, what a disposal releases
start = s.index('// Loads the full layout in a filtered view while the injected failures are active')
end = s.index('void test_failures() {')
new_helper = r'''// Loads the full layout in a filtered view while the injected failures are active; the denied origin must stay silent.
// `frozen` marks the cases in which neither response could be assigned: the request is held and the view is frozen. They
// assert the hold and the single event, and OBSERVE (not assert) what the disposal of the frozen view releases afterwards.
void run_failure_case(world& w, const char* name, const char* spec, bool frozen) {
    const auto p = take_ports();
    view_state healthy;                                       // sibling in the same environment and profile, never filtered
    CHECK(create_view(w, healthy, nullptr) == NEOASTRA_OK);
    view_state a;
    const std::vector<int> initial{p.b};
    CHECK(create_view(w, a, &initial) == NEOASTRA_OK);
    inject(spec);
    // No wait for the end of the navigation: a held request keeps the page from ever finishing.
    neoastra_error_t* navigate_error{};
    CHECK(neoastra_view_navigate(a.view, sv(url(p.m, "/doc?b=" + std::to_string(p.b) + "&t=" + std::to_string(p.t))), &navigate_error) == NEOASTRA_OK);
    settle(5000);
    inject("");
    const auto quarantined = a.quarantined.load();
    std::printf("  [%s] spec='%s': denied-origin http_requests=%llu raw_bytes=%llu partial=%llu; freeze events=%d\n", name, spec,
                static_cast<unsigned long long>(g_host->port_requests(p.b)), static_cast<unsigned long long>(g_host->raw_bytes(p.b)),
                static_cast<unsigned long long>(g_host->partial_bytes(p.b)), quarantined);
    std::printf("    denied-origin requests seen:%s\n", g_host->describe_port(p.b).c_str());
    expect_port_silent(p.b, name);
    expect_reached(p.m, "/doc");                               // positive control: the allowed main document arrived
    CHECK(frozen ? quarantined == 1 : quarantined == 0);       // the host is told exactly once, only when no response could be assigned
    // The sibling in the same environment and profile still navigates, evaluates and fetches.
    const int m2 = g_host->take_port();
    navigate_and_wait(healthy, url(m2, "/doc_healthy"));
    expect_reached(m2, "/doc_healthy");
    CHECK(eval(healthy.view, "1") == "1");
    neoastra_view_release(a.view);
    if (frozen) {
        settle(1500);
        std::printf("    KNOWN BLOCKER, observation after the disposal of the frozen view: denied-origin requests now:%s\n", g_host->describe_port(p.b).c_str());
    }
    neoastra_view_release(healthy.view);
}

'''
s = s[:start] + new_helper + s[end:]
start = s.index('void test_failures() {')
end = s.index('#endif', start)
new_tests = r'''void test_failures() {
    auto w = make_world("failure", false);
    run_failure_case(w, "response construction fails once", "create=1", false);
    run_failure_case(w, "response assignment fails once", "assign=1", false);
    run_failure_case(w, "construction fails every time (the prepared denial answers)", "create=all", false);
    run_failure_case(w, "fresh assignment fails every time (the prepared denial answers)", "assign=all", false);
    // Neither response can be assigned: held and frozen. The disposal of such a view releases the held request (known blocker).
    run_failure_case(w, "construction and prepared answer fail every time (request held, view frozen)", "create=all,prepared=all", true);
    run_failure_case(w, "both assignments fail every time (request held, view frozen)", "assign=all,assign_prepared=all", true);
    destroy_world(w);
    report("failure injection: single and sustained failures are refused with the prepared answer; when no response can be assigned the request is held (see KNOWN BLOCKER)");
}
'''
s = s[:start] + new_tests + s[end:]
open(p, 'w', encoding='utf-8', newline='').write(s)
print('step 6 ok')
