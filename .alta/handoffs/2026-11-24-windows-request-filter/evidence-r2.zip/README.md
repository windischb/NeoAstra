# Windows request filter, revised round: diagnostic and test logs (small text files only, no binaries)

Every directory under logs\ is the log of ONE run. The code state of that run is what matters for reading it:

| directory | code state | outcome |
|---|---|---|
| before | refusal path still logs-and-returns on failure; popup decision still retains its opener; global NOMINMAX flag in the build | RED as intended (regression first): failure.log = a single construction failure let /b_s.js through; main.log = late ALLOW after releasing the opener returned OK after 1033 ms |
| after | all review fixes, parent common fix, no external flags | main, absent, ctest GREEN; failure.log RED because of a TEST HELPER problem (it waited for the end of a navigation that a held request never lets finish) |
| after2 | helper corrected (navigates without waiting) | first four failure cases GREEN; the sustained both-responses-fail case let /b_s.js through when the view was disposed |
| after3 | per-path diagnostics added to the test | the escaped request is /b_s.js (GET), the first denied request, which was the held one |
| after4 | diagnostic build: held deferrals are not released at teardown; "hold on its own" case | hold alone: 0 requests while the view lives; with disposal: /b_s.js still escapes |
| after5 | diagnostic build with a timeline inside the backend | host timestamps missing (test helper used std::getenv for a Win32 variable); also an expectation fixed: after disposal evaluate returns NOT_INITIALIZED (-5), not DISPOSED (-13) |
| after6 | same, host timestamps present, plus switches that skip the handler removal or the controller Close | timeline: the escaped request reaches the host 1.9-7 ms after the first teardown step in every variant; skipping one step does not prevent it |
| after7 | diagnostic build: Stop() / Navigate(about:blank) / 600 ms pump before the teardown | Stop() immediately before the teardown: still escapes; with a 600 ms pump (and about:blank with pump): 0 requests |
| final | cleaned code (no diagnostics), the state of the exported patch | all GREEN; the two frozen-view cases print a KNOWN BLOCKER observation after the disposal |

after4 to after7 are INSTRUMENTED builds (test-only switches in the backend, removed again before the exported patch). Their tools\patch_step*.py show exactly what was added.
harness-all.log is the earlier plain-view comparison (pristine overlay versus modified library, hidden and shown-without-activation window).
Timestamps are QueryPerformanceCounter microseconds, the same clock in the backend trace and in the host fixture. All counters are per port; every case uses its own ports.

Nothing here is a security conformance claim for the frozen-view cases: they document a blocker.
